package com.eduexcellence.studentmsclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentmsClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
